<?php

namespace agencia\Events;

abstract class Event
{
    //
}
